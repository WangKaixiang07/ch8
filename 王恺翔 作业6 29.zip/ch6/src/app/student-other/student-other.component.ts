import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-other',
  templateUrl: './student-other.component.html',
  styleUrls: ['./student-other.component.css']
})
export class StudentOtherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

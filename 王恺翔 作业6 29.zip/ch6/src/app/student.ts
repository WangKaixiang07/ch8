export const STUDENT:Student[]=[
 {name:'wkx',gender: 1,web: 80,embeded:70},
 {name:'wkx',gender: 1,web: 80,embeded:70},
 {name:'wkx',gender: 1,web: 80,embeded:70},
 {name:'wkx',gender: 1,web: 80,embeded:70},

];
export class Student{
     name:string;
     gender:number;
     web:number;
     embeded:number;
 }